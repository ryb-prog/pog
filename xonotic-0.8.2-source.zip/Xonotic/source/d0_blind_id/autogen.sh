#!/bin/sh

set -ex

autoreconf -i
